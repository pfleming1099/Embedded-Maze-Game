################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.c 

OBJS += \
./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.o 

C_DEPS += \
./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.d 


# Each subdirectory must supply rules for building sources it contributes
Middlewares/Third_Party/SystemView/Sample/FreeRTOS/%.o Middlewares/Third_Party/SystemView/Sample/FreeRTOS/%.su Middlewares/Third_Party/SystemView/Sample/FreeRTOS/%.cyclo: ../Middlewares/Third_Party/SystemView/Sample/FreeRTOS/%.c Middlewares/Third_Party/SystemView/Sample/FreeRTOS/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F429xx -c -I../Core/Inc -I../Middlewares/Third_Party/SystemView/Sample/FreeRTOS -I../Middlewares/Third_Party/SystemView/SEGGER -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Middlewares-2f-Third_Party-2f-SystemView-2f-Sample-2f-FreeRTOS

clean-Middlewares-2f-Third_Party-2f-SystemView-2f-Sample-2f-FreeRTOS:
	-$(RM) ./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.cyclo ./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.d ./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.o ./Middlewares/Third_Party/SystemView/Sample/FreeRTOS/SEGGER_SYSVIEW_FreeRTOS.su

.PHONY: clean-Middlewares-2f-Third_Party-2f-SystemView-2f-Sample-2f-FreeRTOS

